#!/usr/bin/python

from spaceInvaders import SpaceInvaders 

if __name__ == "__main__" :
	SpaceInvaders().start()
